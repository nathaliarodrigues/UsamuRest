package br.com.usuario;

import java.text.DateFormat;
import java.util.Date;

import br.com.daos.SimpleEntityManager;

public class Main {

	public static void main(String[] args) {
		
		
		SimpleEntityManager sem = SimpleEntityManager.getInstance();

		CallWS service = new CallWS();
		
		System.out.println("---------Hello-------------");
		service.getHello("Aluno");
		
		System.out.println("---------POST-------------");
		Usuario usuario = new Usuario();
		DateFormat f = DateFormat.getDateInstance();
		try {
			usuario.setCpf("999.999.999-99");
			usuario.setEmail("jolsimar.afonso.defoe@gmail.com");
			usuario.setNome("Jolsimar Afonso DeFo�");
			usuario.setEndereco("Rua das Gr�pias");
			Date dataNascimento = f.parse("07/03/1994");
			usuario.setNascimento(dataNascimento);
			usuario.setNumero(34);
			service.postClient(usuario);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("---------GET-------------");
		service.getClient("1");
		
		System.out.println("---------GET LIST-------------");
		service.getListClient();
		
		System.out.println("---------PUT-------------");
		service.putClient("1", "Oliver da Costa");
		
		System.out.println("---------DELETE-------------");
		service.deleteClient("1");
	}

}
