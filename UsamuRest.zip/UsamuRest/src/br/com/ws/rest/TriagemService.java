package br.com.ws.rest;

import javax.ws.rs.Path;

@Path("Triagem")
public class TriagemService {

	
}
