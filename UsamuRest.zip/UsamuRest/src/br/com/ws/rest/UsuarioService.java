package br.com.ws.rest;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import br.com.daos.UsuarioDAO;
import br.com.daos.SimpleEntityManager;
import br.com.pojos.Sexo;
import br.com.pojos.Usuario;

@Path("/usuario")
public class UsuarioService {

	SimpleEntityManager sem = SimpleEntityManager.getInstance();
	private UsuarioDAO usuarioDAO = new UsuarioDAO(sem.getEntityManager());

	// M�TODO LOGIN
	@POST
	@Path("/login")
	@Produces(MediaType.APPLICATION_JSON)
	public Usuario login(String email, String senha) {
		try {
			sem.getEntityManager().getTransaction().begin();
			Usuario usuario = new Usuario();

			usuario = usuarioDAO.ConsultarEmail(email);
			sem.getEntityManager().getTransaction().commit();
			if (usuario.getSenha() == senha)
				return usuario;
			else {
				return null;
			}
		} catch (Exception e) {
			throw new WebApplicationException(500);
		}
	}

	// M�TODO CONSULTAR
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public Usuario consultar(@PathParam("id") Integer id_usuario) {
		int exceptionNumber = 500;
		try {
			Usuario usuario = usuarioDAO.ConsultarId(id_usuario);
			if (usuario == null) {
				exceptionNumber = 404;
				throw new Exception("Sem clientes nesse Id");

			}
			return usuario;
		} catch (Exception e) {
			throw new WebApplicationException(exceptionNumber);

		}
	}

	// M�TODO CADASTRAR
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response cadastrar(Usuario usuario) {

		UsuarioDAO usuarioDAO = new UsuarioDAO(sem.getEntityManager());

		try {
			sem.beginTransaction();
			usuarioDAO.save(usuario);
			sem.commit();

			return Response.status(200).entity("Usu�rio cadastrado com sucesso").build();
		} catch (Exception e) {
			throw new WebApplicationException(500);
		}
	}

	// METODO LISTAR FUNCIONANDO 
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/usuarios")
	public List<Usuario> listar() {
		int exceptionNumber = 500;
		try {
			List<Usuario> Usuarios = usuarioDAO.listarUsuarios();
			if (Usuarios.isEmpty()) {
				exceptionNumber = 404;
				throw new Exception("Sem clientes registrados");
			}
			return Usuarios;
		} catch (Exception e) {
			throw new WebApplicationException(exceptionNumber);
		}
	}

	// M�TODO GERAR
	@GET
	@Path("/gerar")
	@Produces(MediaType.TEXT_PLAIN)
	public String gerar() {
		try {
			DateFormat f = DateFormat.getDateInstance();
			sem.getEntityManager().getTransaction().begin();
			Usuario u = new Usuario();
			usuarioDAO.save(u);
			sem.getEntityManager().getTransaction().commit();
			return "Usuarios Gerados com sucesso!";
		} catch (Exception e) {
			throw new WebApplicationException(500);
		}
	}

	// M�TODO ATUALIZAR
	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response atualizar(@PathParam("id") int id, Usuario Usuario) {
		int exceptionNumber = 500;
		try {
			Usuario usuario = usuarioDAO.ConsultarId(id);
			if (Usuario == null) {
				exceptionNumber = 404;
				throw new Exception("Sem clientes com esse id");
			} else {
				sem.getEntityManager().getTransaction().begin();
				Usuario.setId(id);
				usuarioDAO.save(Usuario);
				sem.getEntityManager().getTransaction().commit();
				return Response.status(200).entity("Usuario alterado com sucesso").build();
			}
		} catch (Exception e) {
			throw new WebApplicationException(exceptionNumber);
		}
	}

	// M�TODO DELETAR
	@DELETE
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deletar(@PathParam("id") int id_Usuario) {
		int exceptionNumber = 500;
		try {
			Usuario Usuario = usuarioDAO.ConsultarId(id_Usuario);
			if (Usuario == null) {
				exceptionNumber = 404;
				throw new Exception("Sem cliente no id");
			}
			sem.getEntityManager().getTransaction().begin();
			usuarioDAO.delete(Usuario);
			sem.getEntityManager().getTransaction().commit();
			return Response.status(200).entity("Usuario exclu�do com sucesso").build();
		} catch (Exception e) {
			throw new WebApplicationException(exceptionNumber);
		}
	}

}