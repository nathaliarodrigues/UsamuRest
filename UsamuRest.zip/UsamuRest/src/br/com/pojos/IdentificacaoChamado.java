package br.com.pojos;

import javax.xml.bind.annotation.XmlEnum;

@XmlEnum
public enum IdentificacaoChamado {
  CPF, NUMEROCELULAR;
}
