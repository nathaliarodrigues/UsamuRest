package br.com.pojos;


import java.util.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Funcionario {
	@Id
	@GeneratedValue
	private int id;
	@ManyToOne( targetEntity = Unidade.class)
	private Unidade unidade;

	private String nomeFuncionario;
	private String unidadeFuncionario;
	private String emailFuncionario;
	private String senhaFuncionario;

	public Funcionario() {

	}

	public Funcionario(Unidade unidade, String nomeFuncionario, String unidadeFuncionario,
			String emailFuncionario, String senhaFuncionario) {
		this.unidade = unidade;
		this.nomeFuncionario = nomeFuncionario;
		this.unidadeFuncionario = unidadeFuncionario;
		this.emailFuncionario = emailFuncionario;
		this.senhaFuncionario = senhaFuncionario;
	}

	public String getNomeFuncionario() {
		return nomeFuncionario;
	}

	public void setNomeFuncionario(String nomeFuncionario) {
		this.nomeFuncionario = nomeFuncionario;
	}

	public String getEmailFuncionario() {
		return emailFuncionario;
	}

	public void setEmailFuncionario(String emailFuncionario) {
		this.emailFuncionario = emailFuncionario;
	}

	public void setUnidadeFuncionario(String unidadeFuncionario) {
		unidadeFuncionario = unidadeFuncionario;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUnidadeFuncionario() {
		return unidadeFuncionario;
	}

	public void setEmailFuncionario() {
		this.emailFuncionario = emailFuncionario;
	}

	public String getSenhaFuncionario() {
		return senhaFuncionario;
	}

	public void setSenhaFuncionario(String senhaFuncionario) {
		this.senhaFuncionario = senhaFuncionario;
	}
	public Funcionario(String nomeFuncionario, String unidadeFuncionario, String emailFuncionario, String senhaFuncionario){
		
		this.nomeFuncionario = nomeFuncionario;
		this.unidadeFuncionario = unidadeFuncionario;
		this.emailFuncionario = emailFuncionario;
		this.senhaFuncionario = senhaFuncionario;
		
	}
}
