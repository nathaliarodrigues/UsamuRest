package br.com.pojos;

import javax.xml.bind.annotation.XmlEnum;

@XmlEnum
public enum TipoSanguineo {
 A , B, AB, O;
}
