package br.com.pojos;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Unidade {
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private int id;
	@XmlElementWrapper
	@OneToMany (mappedBy="unidade", targetEntity = Chamado.class, cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
	private List<Chamado> chamado = new ArrayList<Chamado>();
	@XmlElementWrapper
	@OneToMany ( targetEntity = Funcionario.class, cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
	private List<Funcionario> funcionario = new ArrayList<Funcionario>();
	
	// Informa��es Funcionario
	private String nomeEntidade;
	private int codigoValidacao;
	private String funcao;

	public Unidade() {

	}

	public List<Funcionario> getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(List<Funcionario> funcionario) {
		this.funcionario = funcionario;
	}

	public int getCodigoValidacao() {
		return codigoValidacao;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNomeEntidade() {
		return nomeEntidade;
	}

	public void setNomeEntidade(String nomeEntidade) {
		this.nomeEntidade = nomeEntidade;
	}

	public int getCodidoValidacao() {
		return codigoValidacao;
	}

	public void setCodigoValidacao(int codigoValidacao) {
		this.codigoValidacao = codigoValidacao;
	}

	private String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}
	
	public Unidade ( Integer id,List<Chamado> chamado, List<Funcionario> funcionario,
			String nomeEntidade,Integer CodigoValidacao, String funcao){
		
		this.chamado = chamado;
		this.funcionario = funcionario;
		this.codigoValidacao = codigoValidacao;
		this.nomeEntidade = nomeEntidade;
		this.funcao = funcao;
		{
	}
		
	}

}
