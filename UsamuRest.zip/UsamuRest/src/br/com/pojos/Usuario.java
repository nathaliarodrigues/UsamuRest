package br.com.pojos;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name="usuarios")
public class Usuario {
	@Id
	// dados pessoais
	@GeneratedValue
	private int id;
	
	@OneToOne(targetEntity = Chamado.class, cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "id_chamado")
	@XmlElementWrapper
	private List<Chamado> chamado;

	@ManyToMany(targetEntity = Triagem.class, cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@XmlElementWrapper
	private List<Triagem> triagem = new ArrayList<Triagem>();
	
	@ManyToMany(targetEntity = ContatoEmergencia.class, cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@XmlElementWrapper
	private List<ContatoEmergencia> contatoEmergencia = new ArrayList<ContatoEmergencia>();

	private String nome;
	private String cpf;
	private Sexo sexo;
	private Date dataNascimento;
	private String email;
	private String senha;
	private String telefone;
	private String celular;

	// endere�o
	private String estado;
	private String cidade;
	private String cep;
	private String rua;
	private String bairro;
	private int numero;
	private String complemento;

	// medidas
	private double altura;
	private double peso;

	// Informa��es Medicas
	private String problemasMedicos;
	private String deficiencia;
	private String alergia;
	private boolean doador;
	private TipoSanguineo tipoSanguineo;
	private FatorRh fatorRh;

	// Informa��es adicionais
	private String TipoConvenio;

	// Outas Informa�oes
	private String OutrasInformacoes;

	public Usuario() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Chamado> getChamado() {
		return chamado;
	}

	public void setChamado(List<Chamado> chamado) {
		this.chamado = chamado;
	}

	public List<Triagem> getTriagem() {
		return triagem;
	}

	public void setTriagem(List<Triagem> triagem) {
		this.triagem = triagem;
	}

	public List<ContatoEmergencia> getContatoEmergencia() {
		return contatoEmergencia;
	}

	public void setContatoEmergencia(List<ContatoEmergencia> contatoEmergencia) {
		this.contatoEmergencia = contatoEmergencia;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Sexo getSexo() {
		return sexo;
	}

	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public String getProblemasMedicos() {
		return problemasMedicos;
	}

	public void setProblemasMedicos(String problemasMedicos) {
		this.problemasMedicos = problemasMedicos;
	}

	public String getDeficiencia() {
		return deficiencia;
	}

	public void setDeficiencia(String deficiencia) {
		this.deficiencia = deficiencia;
	}

	public String getAlergia() {
		return alergia;
	}

	public void setAlergia(String alergia) {
		this.alergia = alergia;
	}

	public boolean isDoador() {
		return doador;
	}

	public void setDoador(boolean doador) {
		this.doador = doador;
	}

	public TipoSanguineo getTipoSanguineo() {
		return tipoSanguineo;
	}

	public void setTipoSanguineo(TipoSanguineo tipoSanguineo) {
		this.tipoSanguineo = tipoSanguineo;
	}

	public FatorRh getFatorRh() {
		return fatorRh;
	}

	public void setFatorRh(FatorRh fatorRh) {
		this.fatorRh = fatorRh;
	}

	public String getTipoconvenio() {
		return TipoConvenio;
	}

	public void setTipoConvenio(String tipoConvenio) {
		TipoConvenio = tipoConvenio;
	}

	public String getOutrasInformacoes() {
		return OutrasInformacoes;
	}

	public void setOutrasInformacoes(String outrasInformacoes) {
		OutrasInformacoes = outrasInformacoes;
	}
	
	public Usuario (Integer id, List<Chamado> chamado, List<Triagem> triagem, List<ContatoEmergencia> contatoEmergencia, String noome, String cpf, Sexo sexo,
		Date dataNacimento, String email, String senha, String telefone, String celular, String cidade, String estado, String cep,String rua, String bairro, Integer numero,
		String complemento, double altua, double peso, String problemasMedicos, String deficiencia, String alergia, boolean doador, TipoSanguineo tipoSanguineo, FatorRh fatorRh, String tipoConvenio, String OutrasInformacoes){
		
		this.id = id;
		this.chamado = chamado;
		this.triagem = triagem;
		this.contatoEmergencia = contatoEmergencia;
		this.nome = nome;
		this.cpf = cpf;
		this.sexo = sexo;
		this.dataNascimento = dataNascimento;
		this.email = email;
		this.senha = senha;
		this.telefone = telefone;
		this.celular = celular;
		this.cidade = cidade;
		this.estado = estado;
		this.cep = cep;
		this.rua = rua;
		this.bairro = bairro;
		this.numero = numero;
		this.complemento = complemento;
		this.altura = altura;
		this.peso = peso;
		this.problemasMedicos = problemasMedicos;
		this.deficiencia = deficiencia; 
		this.alergia = alergia;
		this.doador = doador;
		this.tipoSanguineo = tipoSanguineo;
		this.fatorRh = fatorRh;
		this.TipoConvenio = TipoConvenio;
		this.OutrasInformacoes = OutrasInformacoes;
		
		
				
		
		
	}
	
}