package br.com.pojos;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlEnum;

@XmlEnum
public enum FatorRh {
	
	//private FatorRh fatorRh;

	POSITIVO, NEGATIVO;
}
