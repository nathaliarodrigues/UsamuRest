package br.com.pojos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Triagem  {
	@Id
	@GeneratedValue
	private int id;
	//@ManyToOne ( targetEntity = Triagem.class, cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
	//private  Chamado chamado;
	
	//OneToMany
	@XmlElementWrapper
	@ManyToMany (targetEntity = Sintomas.class, cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
	private List<Sintomas> sintomas = new ArrayList<Sintomas>();
	@XmlElementWrapper
	@ManyToMany (mappedBy="triagem", cascade = CascadeType.ALL, fetch= FetchType.LAZY, targetEntity = Usuario.class)
	private List<Usuario> usuario = new ArrayList<Usuario>(); // n�o existe mais
	
	//ManyToOne
	//Usuario usuario;
	
	private String nome;
	private Date data;
	
	public Triagem(){
		
	}

/*	public Chamado getChamado() {
		return chamado;
	}

	public void setChamado(Chamado chamado) {
		this.chamado = chamado;
	}
*/
	public List<Sintomas> getSintomas() {
		return sintomas;
	}

	public void setSintomas(List<Sintomas> sintomas) {
		this.sintomas = sintomas;
	}

	public List<Usuario> getUsuario() {
		return usuario;
	}

	public void setUsuario(List<Usuario> Usuario) {
		this.usuario = Usuario;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}
	
	public Triagem(Integer id, List<Sintomas> sintomas, List<Usuario> usuario, String nome, Date data){
		
		this.id = id;
		this.sintomas = sintomas;
		this.usuario = usuario;
		this.nome = nome;
		this.data = data;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
