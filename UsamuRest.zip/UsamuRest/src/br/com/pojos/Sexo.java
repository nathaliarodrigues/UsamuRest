package br.com.pojos;

import javax.xml.bind.annotation.XmlEnum;

@XmlEnum
public enum Sexo {
	MASCULINO, FEMININO;
}
