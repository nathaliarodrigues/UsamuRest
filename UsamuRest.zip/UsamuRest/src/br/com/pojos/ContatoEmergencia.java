package br.com.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class ContatoEmergencia {
	@Id
	@GeneratedValue
	private int id;
	@XmlElementWrapper
	@ManyToMany ( mappedBy="contatoEmergencia", cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = Usuario.class)
	private List<Usuario> Usuario = new ArrayList<Usuario>();
	
	private String nome;
	private int telefone;
	private String endereco;
	private String grauParentesco;

	public ContatoEmergencia() {

	}

	public List<Usuario> getUsuario() {
		return Usuario;
	}

	public void setUsuario(List<Usuario> Usuario) {
		this.Usuario = Usuario;
	}

	public void setGrauParentesco(String grauParentesco) {
		this.grauParentesco = grauParentesco;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getGrauParentesco() {
		return grauParentesco;
	}

	public void setGrauParentesco() {
		this.grauParentesco = grauParentesco;
	}
	public ContatoEmergencia(String nome, String endereco, Integer telefone, String grauParentesco){
		
		this.nome = nome;
		this.endereco = endereco;
		this.telefone = telefone;
		this.grauParentesco = grauParentesco;
	}
}
