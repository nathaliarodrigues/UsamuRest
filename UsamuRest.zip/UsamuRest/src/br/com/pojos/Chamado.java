package br.com.pojos;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Chamado {
	@Id
	@GeneratedValue
	private int id;
	
	@OneToOne (mappedBy="chamado", targetEntity = Usuario.class, cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Usuario usuario;
	
	@ManyToOne(targetEntity = Unidade.class, fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	@JoinColumn (name="id_unidade")
	private Unidade unidade;

	// Infor��es do solicitante
	private IdentificacaoChamado identificacao;
	private String solicitante;
	private String telefoneSolicitante;
	private Motivo motivo;

	// Informa��es Vitima
	private String nomePaciente;
	private Sexo sexo;
	private String cidade;
	private String bairro;
	private String rua;
	private int numeroRua;
	private String referencia;
	private String descricaoOcorrencia;

	// Informa��o autom�tica
	private String contatosEmergencia;

	public Chamado() {

	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Unidade getCadastroUnidade() {
		return unidade;
	}

	public void setCadastroUnidade(Unidade unidade) {
		this.unidade = unidade;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public IdentificacaoChamado getIdentificacao() {
		return identificacao;
	}

	public void setIdentificacao(IdentificacaoChamado identificacao) {
		this.identificacao = identificacao;
	}

	public String getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(String solicitante) {
		this.solicitante = solicitante;
	}

	public String getTelefoneSolicitante() {
		return telefoneSolicitante;
	}

	public void setTelefoneSolicitante(String telefoneSolicitante) {
		this.telefoneSolicitante = telefoneSolicitante;
	}

	public Motivo getMotivo() {
		return motivo;
	}

	public void setMotivo(Motivo motivo) {
		this.motivo = motivo;
	}

	public String getNomePaciente() {
		return nomePaciente;
	}

	public void setNomePaciente(String nomePaciente) {
		this.nomePaciente = nomePaciente;
	}

	public Sexo getSexo() {
		return sexo;
	}

	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public int getNumeroRua() {
		return numeroRua;
	}

	public void setNumeroRua(int numeroRua) {
		this.numeroRua = numeroRua;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getDescricaoOcorrencia() {
		return descricaoOcorrencia;
	}

	public void setDescricaoOcorrencia(String descricaoOcorrencia) {
		this.descricaoOcorrencia = descricaoOcorrencia;
	}

	public String getContatosEmergencia() {
		return contatosEmergencia;
	}

	public void setContatosEmergencia(String contatosEmergencia) {
		this.contatosEmergencia = contatosEmergencia;
	}
	public Chamado(Integer id, Usuario usuario, Unidade unidade,IdentificacaoChamado identificacaoChamado, String solicitante, String telefoneSolicitante, Motivo motivo, String nomePaciente, Sexo sexo,
String cidade, String bairro, String rua, Integer numeroRua, String referencia, String descricaoOcorrencia, String contatosEmergencia){
		
		this.id = id;
		this.usuario = usuario;
		this.unidade = unidade;
		this.identificacao = identificacaoChamado;
		this.solicitante = solicitante;
		this.telefoneSolicitante = telefoneSolicitante;
		this.motivo = motivo;
		this.nomePaciente = nomePaciente;
		this.sexo = sexo;
		this.cidade = cidade;
		this.bairro = bairro;
		this.rua = rua;
		this.numeroRua  = numeroRua;
		this.referencia = referencia;
		this.descricaoOcorrencia = descricaoOcorrencia;
		
		
		
		
		
		
	}

}
