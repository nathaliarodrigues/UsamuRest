package br.com.daos;

import javax.persistence.EntityManager;

import br.com.pojos.Triagem;

public class TriagemDAO extends GenericDAO<Integer, Triagem> {

	public TriagemDAO(EntityManager entity) {
		super(entity);
	}

}
