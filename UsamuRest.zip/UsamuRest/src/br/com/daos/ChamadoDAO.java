package br.com.daos;

import javax.persistence.EntityManager;
import br.com.pojos.Unidade;
import br.com.pojos.Chamado;

public class ChamadoDAO  extends GenericDAO<Integer, Chamado> {

	public ChamadoDAO(EntityManager entityManager) {
		super(entityManager);

}
	}
