package br.com.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.pojos.Usuario;

public class UsuarioDAO extends GenericDAO<Integer, Usuario> {

	public UsuarioDAO(EntityManager entity) {
		super(entity);
	}

	@SuppressWarnings("unchecked")
	public List<Usuario> listarUsuarios() {
		this.em.getTransaction().begin();
		Query consulta = this.em.createQuery("Select Usuario from Usuario as Usuario");
		List<Usuario> Usuarios = consulta.getResultList();
		this.em.getTransaction().commit();
		return Usuarios;
	}

	public Usuario ConsultarId(int id) {
		this.em.getTransaction().begin();
		Usuario usuario = this.getById(id);
		this.em.getTransaction().commit();
		return usuario;
	}

	public Usuario ConsultarEmail(String email) {
		this.em.getTransaction().begin();
		Integer id = null;
		Usuario usuario = this.getById(id);
		this.em.getTransaction().commit();
		return usuario;
	}

		public Usuario buscaUserSenha(String user, String senha) {

		em.getTransaction().begin();
		Usuario usuario = null;
		Query query = em.createQuery(
				"Select usuario from Usuario usuario where usuario.user = :user and usuario.senha = :senha");
		query.setParameter("user", user);
		query.setParameter("senha", senha);

		usuario = (Usuario) query.getSingleResult();

		em.getTransaction().commit();

		return usuario;
	}

}
