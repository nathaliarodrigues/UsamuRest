package br.com.daos;

import javax.persistence.EntityManager;
import br.com.pojos.Sintomas;
public class SintomaDAO extends GenericDAO<Integer, Sintomas> {

	public SintomaDAO(EntityManager entity) {
		super(entity);
	}

}
