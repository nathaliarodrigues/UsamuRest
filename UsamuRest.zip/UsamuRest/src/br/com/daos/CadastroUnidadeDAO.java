package br.com.daos;

import javax.persistence.EntityManager;

import br.com.pojos.Unidade;



public class CadastroUnidadeDAO  extends GenericDAO<Integer, Unidade> {

	public CadastroUnidadeDAO(EntityManager entityManager) {
		super(entityManager);
		
	}
	
	}
