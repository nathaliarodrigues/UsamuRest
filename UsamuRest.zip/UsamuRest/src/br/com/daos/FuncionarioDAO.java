package br.com.daos;

import javax.persistence.EntityManager;

import br.com.pojos.Unidade;
import br.com.pojos.Funcionario;

public class FuncionarioDAO extends GenericDAO<Integer, Funcionario> {

	public FuncionarioDAO(EntityManager entityManager) {
		super(entityManager);

	}

}