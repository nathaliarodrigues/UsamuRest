package br.com.daos;

import javax.persistence.EntityManager;

import br.com.pojos.Unidade;
import br.com.pojos.ContatoEmergencia;

public class ContatoEmergenciaDAO extends GenericDAO<Integer, ContatoEmergencia> {

	public ContatoEmergenciaDAO(EntityManager entityManager) {
		super(entityManager);

	}
}